import { ResearchQueryResponse, ResearchDiscoveryResponse } from './api';

export const fixtureChunkCache: Record<string, string> = {
  'mock-chunk-1': 'The quick brown fox jumps over the lazy dog. This is a local PDF chunk.',
  'mock-chunk-2': 'Web search indicates that the weather tomorrow will be sunny with a high of 75F.',
};

export async function runResearchFixture(query: string, webSearch: boolean): Promise<ResearchQueryResponse> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        original_query: query,
        sub_questions: [
          'What does the local PDF say about animals?',
          'What is the weather forecast according to the web?'
        ],
        findings: [
          {
            sub_question: 'What does the local PDF say about animals?',
            evidence: 'According to the local source [1], the quick brown fox jumps over the lazy dog.',
            insufficient_evidence: false,
          },
          {
            sub_question: 'What is the weather forecast according to the web?',
            evidence: webSearch 
              ? 'The web source [2] indicates sunny weather with a high of 75F.'
              : 'Web search was disabled, so no weather forecast is available.',
            insufficient_evidence: !webSearch,
          }
        ],
        overall_summary: 'The research indicates multiple findings. Local sources describe an animal scenario [1]. ' + 
          (webSearch ? 'Web sources provided a weather forecast [2].' : 'Web sources were not consulted.'),
        sources: [
          {
            chunk_id: 'mock-chunk-1',
            source_id: 'local-source-id',
            document_id: 'doc-pdf-001',
            page_number: 1,
            similarity_score: 0.95
          },
          ...(webSearch ? [{
            chunk_id: 'mock-chunk-2',
            source_id: 'web-source-id',
            document_id: 'doc-url-002',
            page_number: 0,
            similarity_score: 0.88
          }] : [])
        ],
        metadata: {
          model: 'claude-fixture',
          chunks_retrieved: webSearch ? 2 : 1,
          context_chars: 150
        }
      });
    }, 2000); // Simulate network delay
  });
}

export async function runResearchDiscoveryFixture(topic: string, webSearch: boolean): Promise<ResearchDiscoveryResponse> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        topic: topic,
        questions: [
          { id: 'q1', question: `What is the history of ${topic}?`, category: 'History' },
          { id: 'q2', question: `How does ${topic} affect the economy?`, category: 'Economics' },
          { id: 'q3', question: `What are the legal implications of ${topic}?`, category: 'Legal' },
          { id: 'q4', question: `Who are the key stakeholders in ${topic}?`, category: 'Stakeholders' },
          { id: 'q5', question: `What is the future outlook for ${topic}?`, category: 'Future' },
        ]
      });
    }, 1500);
  });
}
